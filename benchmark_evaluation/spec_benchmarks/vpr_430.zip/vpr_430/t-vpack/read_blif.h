void read_blif (char *blif_file, int lut_size);
void echo_input (char *blif_file, int lut_size, char *echo_file); 
