boolean is_opin (int ipin);

void load_one_clb_fanout_count (int subblock_lut_size, t_subblock
         *subblock_inf, int num_subblocks, int *num_uses_of_clb_ipin,
         int *num_uses_of_sblk_opin, int iblk);
