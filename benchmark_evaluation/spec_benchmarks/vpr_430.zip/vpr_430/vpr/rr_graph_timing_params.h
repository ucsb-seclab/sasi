void add_rr_graph_C_from_switches (float C_ipin_cblock);
