void print_netlist (char *foutput, char *net_file, t_subblock_data
          subblock_data);
